export function cal()
{
alert("CALCULATE RATING IMPORTED");
}