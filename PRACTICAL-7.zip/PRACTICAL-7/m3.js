export function val()
{
alert("VALIDATE INFO IMPORTED");
}