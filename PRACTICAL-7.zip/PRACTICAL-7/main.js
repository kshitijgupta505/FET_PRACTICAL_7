import {cal} from "./m1.js";
import { propa } from "./m2.js";
import { val } from "./m3.js";

function createA()
{
cal();
propa();
val();
}
//createA();
let test = 'IT WORKED';
window.createA=createA
